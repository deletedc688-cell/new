import discord
from discord.ext import commands
from PIL import Image, ImageDraw, ImageFont
import aiohttp
import os
import asyncio
from utils.Tools import *

class Status(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # background rotation task
        self.rotate_task = self.bot.loop.create_task(self._rotate_loop())

    async def _rotate_loop(self):
        await self.bot.wait_until_ready()
        from utils.Tools import read_json, write_json
        while True:
            try:
                data = read_json('data/bot_presence.json')
                rotate = data.get('rotate') if isinstance(data, dict) else None
                # Check temporary rotation first (temp overrides regular rotate)
                temp = data.get('temp', {"enabled": False}) if isinstance(data, dict) else {"enabled": False}
                if temp.get('enabled'):
                    items = temp.get('items', [])
                    if items:
                        idx = temp.get('current', 0) % len(items)
                        item = items[idx]

                        ptype = item.get('type')
                        text = item.get('text')
                        url = item.get('url')
                        status_str = item.get('status', 'online')

                        status_enum = getattr(discord.Status, status_str, discord.Status.online)

                        if ptype == 'playing':
                            activity = discord.Game(name=text)
                        elif ptype == 'listening':
                            activity = discord.Activity(type=discord.ActivityType.listening, name=text)
                        elif ptype == 'watching':
                            activity = discord.Activity(type=discord.ActivityType.watching, name=text)
                        elif ptype == 'streaming':
                            try:
                                data_defaults = read_json('data/bot_presence.json')
                                default_stream = data_defaults.get('defaults', {}).get('stream_url') if isinstance(data_defaults, dict) else None
                            except Exception:
                                default_stream = None
                            stream_url = url or default_stream or 'https://twitch.tv/'
                            activity = discord.Streaming(name=text or 'CRIMSON ON TOP', url=stream_url)
                        elif ptype in ('competing', 'compete'):
                            activity = discord.Activity(type=discord.ActivityType.competing, name=text)
                        else:
                            activity = None

                        await self.bot.change_presence(status=status_enum, activity=activity)

                        temp['current'] = (idx + 1) % len(items)
                        data['temp'] = temp
                        try:
                            write_json('data/bot_presence.json', data)
                        except Exception:
                            pass

                        await asyncio.sleep(temp.get('interval', 300))
                        continue

                # fallback to regular rotate
                if not rotate or not rotate.get('enabled'):
                    await asyncio.sleep(10)
                    continue

                items = rotate.get('items', [])
                if not items:
                    await asyncio.sleep(10)
                    continue

                idx = rotate.get('current', 0) % len(items)
                item = items[idx]

                ptype = item.get('type')
                text = item.get('text')
                url = item.get('url')
                status_str = item.get('status', 'online')

                status_enum = getattr(discord.Status, status_str, discord.Status.online)

                if ptype == 'playing':
                    activity = discord.Game(name=text)
                elif ptype == 'listening':
                    activity = discord.Activity(type=discord.ActivityType.listening, name=text)
                elif ptype == 'watching':
                    activity = discord.Activity(type=discord.ActivityType.watching, name=text)
                elif ptype == 'streaming':
                    try:
                        data_defaults = read_json('data/bot_presence.json')
                        default_stream = data_defaults.get('defaults', {}).get('stream_url') if isinstance(data_defaults, dict) else None
                    except Exception:
                        default_stream = None
                    stream_url = url or default_stream or 'https://twitch.tv/'
                    activity = discord.Streaming(name=text or 'CRIMSON ON TOP', url=stream_url)
                elif ptype in ('competing', 'compete'):
                    activity = discord.Activity(type=discord.ActivityType.competing, name=text)
                else:
                    activity = None

                await self.bot.change_presence(status=status_enum, activity=activity)

                rotate['current'] = (idx + 1) % len(items)
                data['rotate'] = rotate
                try:
                    write_json('data/bot_presence.json', data)
                except Exception:
                    pass

                await asyncio.sleep(rotate.get('interval', 300))
            except Exception as e:
                print(f"Rotate loop error: {e}")
                await asyncio.sleep(10)

    @commands.command(name="status", help="Shows the status of the user in detail.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def status(self, ctx, user: discord.User = None):
        user = user or ctx.author
        processing = await ctx.send("<a:loading:1246691973633671268> Loading Status...")
        embed = discord.Embed(title=f"{user.display_name}'s Status", color=0x000000)

        status_emoji = {
            "online": "<:online:1329382084837507092> Online",
            "idle": "<:idle:1329382255046430740> Idle",
            "dnd": "<:dnd:1329382206921248808> Do Not Disturb",
            "offline": "<:offline:1329382356804440107> Offline"
        }

        member = None
        for guild in self.bot.guilds:
            member = guild.get_member(user.id)
            if member:
                break

        if member:
            status = status_emoji.get(str(member.status), "<:offline:1329382356804440107> Offline")
            embed.add_field(name="Status:", value=status, inline=False)

            avatar_url = member.avatar.url if member.avatar else member.default_avatar.url
            embed.set_thumbnail(url=avatar_url)

            platform = self.get_platform(member)
            embed.add_field(name="Platform:", value=platform, inline=False)

            custom_status = self.get_custom_status(member)
            if custom_status:
                embed.add_field(name="Custom Status:", value=custom_status, inline=False)

            activity_text = self.get_activity_text(member.activities)
            if activity_text:
                embed.add_field(name="__Activity__:", value=activity_text, inline=False)

            for activity in member.activities:
                if isinstance(activity, discord.Spotify):
                    song_name = activity.title
                    album_cover_url = str(activity.album_cover_url)

                    album_image_path = 'data/pictures/album_image.png'

                    async with aiohttp.ClientSession() as session:
                        async with session.get(album_cover_url) as resp:
                            if resp.status == 200:
                                album_data = await resp.read()
                                with open(album_image_path, 'wb') as f:
                                    f.write(album_data)

                    card_image_path = self.create_spotify_card(song_name, album_image_path)

                    if os.path.exists(card_image_path):
                        file = discord.File(card_image_path, filename="spotify_card.png")
                        embed.set_image(url="attachment://spotify_card.png")
                    else:
                        await ctx.send("Failed to generate the Spotify card image.")
        else:
            try:
                user = await self.bot.fetch_user(user.id)
                embed.add_field(name="Status:", value="<:offline:1329382356804440107> Offline", inline=False)
                avatar_url = user.default_avatar.url
                embed.set_thumbnail(url=avatar_url)
            except discord.NotFound:
                await ctx.send("User not found.")
                return

        requester_avatar_url = ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
        embed.set_footer(text=f"Requested by {ctx.author.display_name}", icon_url=requester_avatar_url)

        await ctx.send(embed=embed, file=file if 'file' in locals() else None)
        await processing.delete()

    def create_spotify_card(self, song_name, album_image_path):
        card_path = 'data/pictures/spotify.png'
        output_path = 'data/pictures/spotify_card_output.png'

        base_img = Image.open(card_path).convert("RGBA")
        draw = ImageDraw.Draw(base_img)

        album_img = Image.open(album_image_path).convert("RGBA")
        album_img = album_img.resize((160, 160))

        mask = Image.new("L", album_img.size, 0)
        draw_mask = ImageDraw.Draw(mask)
        draw_mask.ellipse((0, 0, 160, 160), fill=255)

        base_img.paste(album_img, (30, 30), mask) 

        font_path = 'utils/arial.ttf'
        font = ImageFont.truetype(font_path, 40)

        truncated_song_name = song_name if len(song_name) <= 60 else song_name[:57] + "..."
        song_name_position = (220, 70) 
        draw.text(song_name_position, truncated_song_name, font=font, fill="white")

        base_img.save(output_path)
        return output_path

    def get_platform(self, member):
        if member.desktop_status != discord.Status.offline:
            return "<:pc:1329382763161321524> Desktop"
        elif member.mobile_status != discord.Status.offline:
            return "<:mobile:1329382816441569372> Mobile"
        elif member.web_status != discord.Status.offline:
            return "<:browser:1329382931449516058> Browser"
        return "Unknown"

    def get_custom_status(self, member):
        for activity in member.activities:
            if isinstance(activity, discord.CustomActivity):
                status_text = activity.name or ""
                if activity.name == "Custom Status":
                    status_text = "‎"
                status_emoji = str(activity.emoji) if activity.emoji else ""

                if status_emoji and not status_text:
                    return status_emoji
                elif status_emoji and status_text:
                    return f"{status_emoji} {status_text}"
                elif status_text:
                    return status_text
        return None

    def get_activity_text(self, activities):
        activity_list = []
        for activity in activities:
            if isinstance(activity, discord.Game):
                activity_list.append(f"Playing {activity.name}")
            elif isinstance(activity, discord.Streaming):
                activity_list.append(f"Streaming {activity.name} on **[Twitch]({activity.url})**")
            elif isinstance(activity, discord.Spotify):
                activity_list.append(f"**[Listening to Spotify](https://open.spotify.com/track/{activity.track_id})**")
            elif isinstance(activity, discord.Activity):
                activity_list.append(f"{activity.type.name.capitalize()} {activity.name}")
        return "\n".join(activity_list) if activity_list else None

    @commands.group(name="bot", invoke_without_command=True)
    @commands.is_owner()
    async def bot(self, ctx):
        """Owner-only group for bot management."""
        await ctx.send("Available subcommands: `status` - set bot activity. Usage: `bot status <type> <message>`")

    @bot.group(name="status", invoke_without_command=True)
    @commands.is_owner()
    async def status_group(self, ctx, activity_type: str = None, *, text: str = None):
        """
        Set the bot's presence activity and save it permanently.
        Usage: bot status <playing|streaming|listening|watching|competing|clear> <text>
        For streaming you can include a URL by separating with `|`, e.g.:
        `bot status streaming CRIMSON ON TOP | https://twitch.tv/your_channel`
        """
        if not activity_type:
            return await ctx.send("Usage: `bot status <playing|streaming|listening|watching|competing|clear> <text>`")
        activity_type = activity_type.lower()

        # Clear saved presence OR revert temporary rotation backup if active
        if activity_type in ("clear", "none"):
            try:
                # Check if temp backup exists and is enabled -> restore backup
                data = read_json('data/bot_presence.json')
                temp = data.get('temp') if isinstance(data, dict) else None
                if temp and temp.get('enabled') and temp.get('backup'):
                    backup = temp.get('backup')
                    # restore backup presence
                    try:
                        if backup and isinstance(backup, dict):
                            ptype = backup.get('type')
                            text = backup.get('text')
                            url = backup.get('url')
                            status_str = backup.get('status', 'online')
                            status_enum = getattr(discord.Status, status_str, discord.Status.online)

                            if ptype == 'playing':
                                activity = discord.Game(name=text)
                            elif ptype == 'listening':
                                activity = discord.Activity(type=discord.ActivityType.listening, name=text)
                            elif ptype == 'watching':
                                activity = discord.Activity(type=discord.ActivityType.watching, name=text)
                            elif ptype == 'streaming':
                                try:
                                    from utils.config import STREAM_URL as DEFAULT_STREAM_URL
                                except Exception:
                                    DEFAULT_STREAM_URL = 'https://twitch.tv/'
                                activity = discord.Streaming(name=text or 'CRIMSON ON TOP', url=url or DEFAULT_STREAM_URL)
                            elif ptype in ('competing', 'compete'):
                                activity = discord.Activity(type=discord.ActivityType.competing, name=text)
                            else:
                                activity = None

                            await self.bot.change_presence(activity=activity, status=status_enum)

                            # remove temp and restore saved presence key
                            data['temp'] = {"enabled": False, "items": [], "interval": 60, "current": 0}
                            data['presence'] = backup
                            try:
                                write_json('data/bot_presence.json', data)
                            except Exception:
                                pass
                            return await ctx.send("✅ Reverted to previous saved presence and cleared temporary rotation.")
                    except Exception:
                        pass

                # Otherwise, clear saved presence as before
                await self.bot.change_presence(activity=None)
                # remove saved presence file if exists
                try:
                    if os.path.exists('data/bot_presence.json'):
                        os.remove('data/bot_presence.json')
                except Exception:
                    pass
                return await ctx.send("✅ Bot activity cleared and saved presence removed.")
            except Exception as e:
                return await ctx.send(f"Failed to clear activity: {e}")

        if not text:
            return await ctx.send("Please provide text for the activity.")

        # Parse text for optional parts separated by '|' (e.g., name | url | status=invisible)
        parts = [p.strip() for p in text.split('|')]
        main_text = parts[0]
        extra_parts = parts[1:]

        saved_text = main_text
        saved_url = None
        saved_status = 'online'

        # parse extra parts for url and status
        for part in extra_parts:
            if part.lower().startswith('status='):
                saved_status = part.split('=', 1)[1].strip().lower()
            elif part.lower().startswith('url='):
                saved_url = part.split('=', 1)[1].strip()
            elif part.startswith('http'):
                saved_url = part

        if activity_type == "playing":
            activity = discord.Game(name=main_text)
        elif activity_type == "listening":
            activity = discord.Activity(type=discord.ActivityType.listening, name=main_text)
        elif activity_type == "watching":
            activity = discord.Activity(type=discord.ActivityType.watching, name=main_text)
        elif activity_type == "streaming":
            # Allow users to provide a URL with pipe separator: name | url OR name | url | status=invisible
            from utils.config import STREAM_URL as DEFAULT_STREAM_URL

            url = saved_url
            if not url and len(extra_parts) and extra_parts[0].startswith('http'):
                url = extra_parts[0]

            # Check persisted default stream URL in data/bot_presence.json
            try:
                from utils.Tools import read_json
                data_defaults = read_json('data/bot_presence.json')
                default_stream = data_defaults.get('defaults', {}).get('stream_url') if isinstance(data_defaults, dict) else None
            except Exception:
                default_stream = None

            # If still no URL, fall back to persisted default or configured default
            if not url:
                url = default_stream or DEFAULT_STREAM_URL

            activity = discord.Streaming(name=main_text, url=url)
            saved_url = url
        elif activity_type in ("competing", "compete", "competition"):
            activity = discord.Activity(type=discord.ActivityType.competing, name=main_text)
        else:
            return await ctx.send("Invalid activity type. Valid: playing, streaming, listening, watching, competing, clear")

        # determine status enum
        try:
            status_enum = getattr(discord.Status, saved_status)
        except Exception:
            status_enum = discord.Status.online
            saved_status = 'online'

        try:
            await self.bot.change_presence(activity=activity, status=status_enum)

            # persist presence
            try:
                write_json('data/bot_presence.json', {
                    "presence": {
                        "type": activity_type,
                        "text": saved_text,
                        "url": saved_url,
                        "status": saved_status
                    }
                })
            except Exception:
                pass

            await ctx.send(f"✅ Bot status set and saved: **{activity_type.capitalize()} {saved_text}** (status: {saved_status})")
        except Exception as e:
            await ctx.send(f"Failed to set presence: {e}")

    # assign group variable for subcommands
    status = status_group

    @status.command(name="setstreamurl", aliases=["streamurl","setstream"])
    @commands.is_owner()
    async def set_stream_url(self, ctx, url: str = None):
        """Set or clear the default stream URL used when streaming without an explicit URL.
        Usage:
        - Set: `bot status setstreamurl https://twitch.tv/your_channel`
        - Clear: `bot status setstreamurl` (no arg)
        """
        from utils.Tools import read_json, write_json
        data = read_json('data/bot_presence.json')
        if not isinstance(data, dict):
            data = {}
        defaults = data.get('defaults', {})

        # If no argument given, show current default
        if not url:
            cur = defaults.get('stream_url')
            if cur:
                return await ctx.send(f"Current default stream URL: {cur}\nUse `bot status setstreamurl <url>` to change or `bot status setstreamurl clear` to remove.")
            else:
                return await ctx.send("No default stream URL set. Use `bot status setstreamurl <url>` to set one.")

        # Support clearing with `clear`
        if url.lower() in ('clear', 'remove', 'none'):
            defaults.pop('stream_url', None)
            data['defaults'] = defaults
            try:
                write_json('data/bot_presence.json', data)
            except Exception:
                pass
            return await ctx.send("✅ Default stream URL cleared.")

        if not (url.startswith('http://') or url.startswith('https://')):
            return await ctx.send("Please provide a valid URL starting with http:// or https://")

        defaults['stream_url'] = url
        data['defaults'] = defaults
        try:
            write_json('data/bot_presence.json', data)
        except Exception:
            pass
        await ctx.send(f"✅ Default stream URL set to {url}")

    @bot.command(name="invisible")
    @commands.is_owner()
    async def set_invisible(self, ctx):
        """Set bot to invisible (persisted)."""
        try:
            await self.bot.change_presence(activity=None, status=discord.Status.invisible)
            try:
                write_json('data/bot_presence.json', {
                    "presence": {
                        "type": "none",
                        "text": None,
                        "url": None,
                        "status": "invisible"
                    }
                })
            except Exception:
                pass
            await ctx.send("✅ Bot set to invisible and saved.")
        except Exception as e:
            await ctx.send(f"Failed to set invisible: {e}")

    @bot.command(name="status_rotate", aliases=["stats_r","sr"])
    @commands.is_owner()
    async def status_rotate(self, ctx, *, raw: str = None):
        """Shortcut to add to persistent rotate (keeps after restart).

        Shorthand: `bot status rotate <type> <text>`
        Alias `sr` added for quick use (e.g., `>sr playing Hello world`).
        This command exists for backwards compatibility and simple calls. Use `bot status rotate` group for full management.
        """
        # If user invoked this shorthand, parse and forward to the rotate handler
        if not raw:
            return await ctx.send("Usage: `bot status rotate <type> <text>`")
        parts = raw.split()
        if len(parts) < 2:
            return await ctx.send("Usage: `bot status rotate <type> <text>`")
        atype = parts[0].lower()
        text = " ".join(parts[1:])
        # reuse rotate add logic
        from utils.Tools import read_json, write_json
        data = read_json('data/bot_presence.json')
        if not isinstance(data, dict):
            data = {}
        rotate = data.get('rotate', {"enabled": True, "items": [], "interval": 300, "current": 0})
        parts = [p.strip() for p in text.split('|')]
        main_text = parts[0]
        url = None
        status_val = 'online'
        for part in parts[1:]:
            if part.lower().startswith('status='):
                status_val = part.split('=', 1)[1].strip().lower()
            elif part.lower().startswith('url='):
                url = part.split('=', 1)[1].strip()
            elif part.startswith('http'):
                url = part
        item = {"type": atype, "text": main_text, "url": url, "status": status_val}
        rotate.setdefault('items', []).append(item)
        rotate['enabled'] = True
        data['rotate'] = rotate
        try:
            write_json('data/bot_presence.json', data)
        except Exception:
            pass
        await ctx.send(f"✅ Added to rotation: **{atype} {main_text}** (status: {status_val})")

    @bot.command(name="r", aliases=["sts"])
    @commands.is_owner()
    async def r(self, ctx, *, raw: str = None):
        """Quick alias: `r sts <text>` adds to persistent rotation (defaults to playing).
        Usage examples:
        - `r CRIMSON ON TOP` (adds playing CRIMSON ON TOP)
        - `r streaming CRIMSON | https://twitch.tv/you`"""
        if not raw:
            return await ctx.send("Usage: `r sts <text>`")

        parts = raw.split()
        activity_types = {"playing","streaming","listening","watching","competing","compete","competition"}
        if parts[0].lower() in activity_types and len(parts) >= 2:
            atype = parts[0].lower()
            text = " ".join(parts[1:])
        else:
            atype = 'playing'
            text = raw

        parts2 = [p.strip() for p in text.split('|')]
        main_text = parts2[0].strip()
        if not main_text:
            return await ctx.send("Please provide text for the status.")

        # Enforce Discord activity length limit (safely truncate)
        truncated = False
        if len(main_text) > 128:
            main_text = main_text[:128]
            truncated = True

        url = None
        status_val = 'online'
        for part in parts2[1:]:
            if part.lower().startswith('status='):
                status_val = part.split('=', 1)[1].strip().lower()
            elif part.lower().startswith('url='):
                url = part.split('=', 1)[1].strip()
            elif part.startswith('http'):
                url = part

        from utils.Tools import read_json, write_json
        data = read_json('data/bot_presence.json')
        if not isinstance(data, dict):
            data = {}
        rotate = data.get('rotate', {"enabled": True, "items": [], "interval": 300, "current": 0})
        item = {"type": atype, "text": main_text, "url": url, "status": status_val}
        rotate.setdefault('items', []).append(item)
        rotate['enabled'] = True
        data['rotate'] = rotate

        # Try to set presence immediately so user sees the change right away
        presence_set = False
        try:
            # determine status enum
            try:
                status_enum = getattr(discord.Status, status_val)
            except Exception:
                status_enum = discord.Status.online
                status_val = 'online'

            # build activity object
            if atype == 'playing':
                activity = discord.Game(name=main_text)
            elif atype == 'listening':
                activity = discord.Activity(type=discord.ActivityType.listening, name=main_text)
            elif atype == 'watching':
                activity = discord.Activity(type=discord.ActivityType.watching, name=main_text)
            elif atype == 'streaming':
                # determine stream url fallback
                default_stream = None
                try:
                    default_stream = data.get('defaults', {}).get('stream_url') if isinstance(data, dict) else None
                except Exception:
                    default_stream = None
                if not url:
                    try:
                        from utils.config import STREAM_URL as DEFAULT_STREAM_URL
                    except Exception:
                        DEFAULT_STREAM_URL = 'https://twitch.tv/'
                    url = default_stream or DEFAULT_STREAM_URL
                activity = discord.Streaming(name=main_text or 'CRIMSON ON TOP', url=url)
            elif atype in ('competing', 'compete'):
                activity = discord.Activity(type=discord.ActivityType.competing, name=main_text)
            else:
                activity = None

            await self.bot.change_presence(activity=activity, status=status_enum)
            presence_set = True
        except Exception:
            presence_set = False

        try:
            write_json('data/bot_presence.json', data)
        except Exception:
            pass

        msg = f"✅ Added to rotation: **{atype} {main_text}** (status: {status_val})"
        if truncated:
            msg += " — (truncated to 128 characters)"
        if presence_set:
            msg += " — presence updated now."
        else:
            msg += " — failed to update presence immediately (still saved to rotation)."

        await ctx.send(msg)

    @status.command(name="rotate", aliases=["r","stats"])
    @commands.is_owner()
    async def rotate(self, ctx, action: str = None, *args):
        """Manage rotating statuses (persistent).
        Use `bot status temp ...` for temporary rotation that you can revert with `bot status clear`.
        """
        """Manage rotating statuses.

        Usage examples:
        - Add: `bot status rotate add <type> <text>`
        - Quick add: `bot status rotate <type> <text>`
        - List: `bot status rotate list`
        - Remove: `bot status rotate remove <index>`
        - Start: `bot status rotate start [interval_seconds]`
        - Stop: `bot status rotate stop`
        - Interval: `bot status rotate interval <seconds>`
        - Clear all: `bot status rotate clear`
        """
        from utils.Tools import read_json, write_json

        data = read_json('data/bot_presence.json')
        if not isinstance(data, dict):
            data = {}
        rotate = data.get('rotate', {"enabled": False, "items": [], "interval": 300, "current": 0})

        if not action:
            return await ctx.send("Usage: `bot status rotate <add/list/remove/start/stop/interval/clear>`")

        act = action.lower()

        def save():
            data['rotate'] = rotate
            try:
                write_json('data/bot_presence.json', data)
            except Exception:
                pass

        # Quick add: allow calling `bot status rotate <text>` (defaults to playing)
        control_keywords = {"add","a","list","remove","start","stop","interval","clear"}
        activity_types = {"playing","streaming","listening","watching","competing","compete","competition"}

        if act not in control_keywords:
            # If no additional args, treat the provided action as the text and default to 'playing'
            if not args:
                atype = 'playing'
                text = action
            else:
                # If the first word is a valid activity type, use it as the type
                if act in activity_types:
                    atype = act
                    text = " ".join(args)
                else:
                    # otherwise treat the whole input as text and default to playing
                    atype = 'playing'
                    text = " ".join((action,) + args)

            parts = [p.strip() for p in text.split('|')]
            main_text = parts[0]
            url = None
            status_val = 'online'
            for part in parts[1:]:
                if part.lower().startswith('status='):
                    status_val = part.split('=', 1)[1].strip().lower()
                elif part.lower().startswith('url='):
                    url = part.split('=', 1)[1].strip()
                elif part.startswith('http'):
                    url = part
            item = {"type": atype, "text": main_text, "url": url, "status": status_val}
            rotate.setdefault('items', []).append(item)
            rotate['enabled'] = True
            save()
            return await ctx.send(f"✅ Added to rotation: **{atype} {main_text}** (status: {status_val})")

        # Add
        if act in ("add", "a"):
            if len(args) < 2:
                return await ctx.send("Usage: `bot status rotate add <type> <text> [| url=... | status=...]`")
            atype = args[0].lower()
            text = " ".join(args[1:])
            parts = [p.strip() for p in text.split('|')]
            main_text = parts[0]
            url = None
            status_val = 'online'
            for part in parts[1:]:
                if part.lower().startswith('status='):
                    status_val = part.split('=', 1)[1].strip().lower()
                elif part.lower().startswith('url='):
                    url = part.split('=', 1)[1].strip()
                elif part.startswith('http'):
                    url = part
            item = {"type": atype, "text": main_text, "url": url, "status": status_val}
            rotate.setdefault('items', []).append(item)
            rotate['enabled'] = True
            save()
            return await ctx.send(f"✅ Added to rotation: **{atype} {main_text}** (status: {status_val})")

    @status.group(name="temp", invoke_without_command=True)
    @commands.is_owner()
    async def temp(self, ctx):
        """Temporary rotation commands: add/list/remove/start/stop/interval/clear. Use `bot status temp start` to begin temporary rotation and `bot status clear` to revert."""
        return await ctx.send("Usage: `bot status temp <add/list/remove/start/stop/interval/clear>`")

    @temp.command(name="add")
    @commands.is_owner()
    async def temp_add(self, ctx, atype: str = None, *, text: str = None):
        """Add temporary rotation item (not permanent after clear). Example: `bot status temp add playing CRIMSON ON TOP`"""
        from utils.Tools import read_json, write_json
        if not atype or not text:
            return await ctx.send("Usage: `bot status temp add <type> <text>`")
        data = read_json('data/bot_presence.json')
        if not isinstance(data, dict):
            data = {}
        temp = data.get('temp', {"enabled": False, "items": [], "interval": 60, "current": 0})
        parts = [p.strip() for p in text.split('|')]
        main_text = parts[0]
        url = None
        status_val = 'online'
        for part in parts[1:]:
            if part.lower().startswith('status='):
                status_val = part.split('=', 1)[1].strip().lower()
            elif part.lower().startswith('url='):
                url = part.split('=', 1)[1].strip()
            elif part.startswith('http'):
                url = part
        item = {"type": atype.lower(), "text": main_text, "url": url, "status": status_val}
        temp.setdefault('items', []).append(item)
        data['temp'] = temp
        try:
            write_json('data/bot_presence.json', data)
        except Exception:
            pass
        await ctx.send(f"✅ Added temporary rotate item: **{atype} {main_text}** (status: {status_val})")



    @temp.command(name="list")
    @commands.is_owner()
    async def temp_list(self, ctx):
        """List temporary rotation items."""
        from utils.Tools import read_json
        data = read_json('data/bot_presence.json')
        temp = data.get('temp', {})
        items = temp.get('items', [])
        if not items:
            return await ctx.send("No temporary rotating statuses saved.")
        msg = "**Temporary rotating statuses:**\n"
        for i, it in enumerate(items):
            msg += f"`[{i}]` **{it.get('type')}** {it.get('text')} (status: {it.get('status','online')})\n"
        await ctx.send(msg)


    @temp.command(name="remove")
    @commands.is_owner()
    async def temp_remove(self, ctx, index: int = None):
        """Remove a temporary rotation item by index."""
        from utils.Tools import read_json, write_json
        if index is None:
            return await ctx.send("Provide the index to remove. Use `bot status temp list` to view indices.")
        data = read_json('data/bot_presence.json')
        temp = data.get('temp', {"enabled": False, "items": [], "interval": 60, "current": 0})
        items = temp.get('items', [])
        if index < 0 or index >= len(items):
            return await ctx.send("Index out of range.")
        removed = items.pop(index)
        temp['items'] = items
        data['temp'] = temp
        try:
            write_json('data/bot_presence.json', data)
        except Exception:
            pass
        await ctx.send(f"✅ Removed temporary rotating status: **{removed.get('type')} {removed.get('text')}**")



    @temp.command(name="start")
    @commands.is_owner()
    async def temp_start(self, ctx, interval: int = None):
        """Start temporary rotation. This will backup current saved presence and start rotating temp items."""
        from utils.Tools import read_json, write_json
        data = read_json('data/bot_presence.json')
        if not isinstance(data, dict):
            data = {}
        temp = data.get('temp', {"enabled": False, "items": [], "interval": 60, "current": 0})
        if not temp.get('items'):
            return await ctx.send("No temporary items to rotate. Add with `bot status temp add <type> <text>`")

        # backup current saved presence (if any)
        backup = data.get('presence') if isinstance(data, dict) else None
        temp['backup'] = backup
        if interval and isinstance(interval, int):
            temp['interval'] = interval
        temp['enabled'] = True
        temp['current'] = 0
        data['temp'] = temp
        try:
            write_json('data/bot_presence.json', data)
        except Exception:
            pass
        await ctx.send(f"✅ Temporary rotation started (interval: {temp.get('interval')}s). Use `bot status clear` to stop and revert to previous presence.")



    @temp.command(name="stop")
    @commands.is_owner()
    async def temp_stop(self, ctx):
        """Stop temporary rotation without restoring backup (use `bot status clear` to restore)."""
        from utils.Tools import read_json, write_json
        data = read_json('data/bot_presence.json')
        temp = data.get('temp', {})
        temp['enabled'] = False
        data['temp'] = temp
        try:
            write_json('data/bot_presence.json', data)
        except Exception:
            pass
        await ctx.send("✅ Temporary rotation stopped (backup preserved). Use `bot status clear` to restore backup or `bot status temp clear` to remove temp items.")



    @temp.command(name="interval")
    @commands.is_owner()
    async def temp_interval(self, ctx, seconds: int = None):
        """Set interval for temporary rotation."""
        from utils.Tools import read_json, write_json
        if not seconds or seconds <= 0:
            return await ctx.send("Provide a positive number of seconds: `bot status temp interval 60`")
        data = read_json('data/bot_presence.json')
        temp = data.get('temp', {"enabled": False, "items": [], "interval": 60, "current": 0})
        temp['interval'] = seconds
        data['temp'] = temp
        try:
            write_json('data/bot_presence.json', data)
        except Exception:
            pass
        await ctx.send(f"✅ Temporary rotation interval set to {seconds} seconds.")

    @temp.command(name="clear")
    @commands.is_owner()
    async def temp_clear(self, ctx):
        """Clear temporary rotation items and backup (if any)."""
        from utils.Tools import read_json, write_json
        data = read_json('data/bot_presence.json')
        data['temp'] = {"enabled": False, "items": [], "interval": 60, "current": 0}
        try:
            write_json('data/bot_presence.json', data)
        except Exception:
            pass
        await ctx.send("✅ Temporary rotation cleared.")




"""
@Author: Sonu Jana
    + Discord: me.sonu
    + Community: https://discord.gg/odx (Olympus Development)
    + for any queries reach out Community or DM me.
"""