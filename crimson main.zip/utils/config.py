import os

TOKEN = os.environ.get("TOKEN")
NAME = "CrimSon AsisTant"
server = "https://discord.gg/rUtcksNt "
ch = "https://discord.com/channels/1453066712244162644/1453340586743431212"
OWNER_IDS = [1441835985011867692]
BotName = "CrimSon AsisTant"
serverLink = "https://discord.gg/rUtcksNt "
# Optional default stream URL used when setting streaming activity without a URL
STREAM_URL = os.environ.get("STREAM_URL", "https://twitch.tv/")